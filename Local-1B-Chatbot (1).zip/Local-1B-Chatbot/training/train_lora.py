"""LoRA fine-tuning for the 1B assistant on prepared chat JSONL data."""

from __future__ import annotations

import argparse
import os
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-model",
        default="meta-llama/Llama-3.2-1B-Instruct",
        help="Use the same model family you plan to export and serve.",
    )
    parser.add_argument("--data", default="training/data/agentpack_chat.jsonl")
    parser.add_argument("--output", default="training/output/local-1b-agentpack-lora")
    parser.add_argument("--epochs", type=float, default=1.0)
    parser.add_argument("--max-length", type=int, default=2048)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--gradient-accumulation", type=int, default=16)
    args = parser.parse_args()

    import torch
    from datasets import load_dataset
    from peft import LoraConfig, get_peft_model
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        DataCollatorForLanguageModeling,
        Trainer,
        TrainingArguments,
    )

    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(
            f"{data_path} does not exist. Run prepare_agentpack.py first."
        )

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    dataset = load_dataset("json", data_files=str(data_path), split="train")

    def render(example: dict) -> str:
        messages = example["messages"]
        if getattr(tokenizer, "chat_template", None):
            return tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=False
            )
        return "\n".join(
            f"{message['role'].upper()}: {message['content']}" for message in messages
        )

    def tokenize(example: dict) -> dict:
        return tokenizer(
            render(example),
            truncation=True,
            max_length=args.max_length,
        )

    tokenized = dataset.map(
        tokenize,
        remove_columns=dataset.column_names,
        desc="Tokenizing AgentPack conversations",
    )

    use_cuda = torch.cuda.is_available()
    use_bf16 = use_cuda and torch.cuda.is_bf16_supported()
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=torch.bfloat16 if use_bf16 else None,
    )
    model.config.use_cache = False
    model = get_peft_model(
        model,
        LoraConfig(
            r=16,
            lora_alpha=32,
            lora_dropout=0.05,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        ),
    )
    model.print_trainable_parameters()

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    trainer = Trainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=tokenized,
        data_collator=DataCollatorForLanguageModeling(tokenizer, mlm=False),
        args=TrainingArguments(
            output_dir=args.output,
            num_train_epochs=args.epochs,
            per_device_train_batch_size=args.batch_size,
            gradient_accumulation_steps=args.gradient_accumulation,
            learning_rate=2e-4,
            logging_steps=10,
            save_strategy="epoch",
            report_to="none",
            fp16=use_cuda and not use_bf16,
            bf16=use_bf16,
            gradient_checkpointing=use_cuda,
            optim="adamw_torch",
        ),
    )
    trainer.train()
    trainer.save_model(args.output)
    tokenizer.save_pretrained(args.output)
    print(f"Saved LoRA adapter and tokenizer to {args.output}")
    print(
        "Merge the adapter into the same base model, export it to the runtime "
        "format, and set LOCAL_MODEL_ID to the exported model."
    )


if __name__ == "__main__":
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    main()