"""Prepare nuprl/AgentPack plus identity examples for chat fine-tuning.

The dataset is normalized defensively because AgentPack revisions may expose
different field names or nested trajectory structures.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable
from pathlib import Path
from typing import Any

SYSTEM_PROMPT = (
    "You are Local/1B, a public self-hosted AI assistant running on a server "
    "through an open-weight 1B-class model. Be honest, concise, and helpful."
)
ROLE_ALIASES = {
    "human": "user",
    "user": "user",
    "prompt": "user",
    "instruction": "user",
    "assistant": "assistant",
    "agent": "assistant",
    "bot": "assistant",
    "model": "assistant",
    "system": "system",
}


def as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, dict):
        for key in ("content", "text", "value", "response", "output"):
            if key in value:
                text = as_text(value[key])
                if text:
                    return text
    return ""


def normalize_messages(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list):
        return []
    messages: list[dict[str, str]] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        role_value = str(
            item.get("role")
            or item.get("from")
            or item.get("speaker")
            or item.get("type")
            or ""
        ).lower()
        role = ROLE_ALIASES.get(role_value)
        content = as_text(item.get("content") or item.get("text") or item.get("value"))
        if role and content:
            messages.append({"role": role, "content": content})
    return messages


def first_value(record: dict[str, Any], names: Iterable[str]) -> Any:
    for name in names:
        if name in record and record[name] not in (None, ""):
            return record[name]
    return None


def normalize_record(record: dict[str, Any]) -> list[dict[str, str]]:
    for key in (
        "messages",
        "conversation",
        "conversations",
        "dialogue",
        "trajectory",
        "chat",
        "turns",
    ):
        messages = normalize_messages(record.get(key))
        if len(messages) >= 2:
            return messages

    user_text = as_text(
        first_value(
            record,
            ("instruction", "prompt", "question", "input", "query", "task"),
        )
    )
    assistant_text = as_text(
        first_value(
            record,
            ("output", "response", "answer", "completion", "solution", "target"),
        )
    )
    if user_text and assistant_text:
        return [
            {"role": "user", "content": user_text},
            {"role": "assistant", "content": assistant_text},
        ]
    return []


def with_system_prompt(messages: list[dict[str, str]]) -> list[dict[str, str]]:
    cleaned = [message for message in messages if message["content"]]
    if cleaned and cleaned[0]["role"] == "system":
        return cleaned
    return [{"role": "system", "content": SYSTEM_PROMPT}, *cleaned]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="nuprl/AgentPack")
    parser.add_argument("--split", default="train")
    parser.add_argument("--output", default="training/data/agentpack_chat.jsonl")
    parser.add_argument("--identity", default="training/identity.jsonl")
    parser.add_argument("--max-rows", type=int, default=0)
    args = parser.parse_args()

    from datasets import load_dataset

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    skipped = 0

    dataset = load_dataset(args.dataset, split=args.split)
    with output_path.open("w", encoding="utf-8") as output:
        for record in dataset:
            if args.max_rows and count >= args.max_rows:
                break
            messages = normalize_record(dict(record))
            if len(messages) < 2:
                skipped += 1
                continue
            output.write(json.dumps({"messages": with_system_prompt(messages)}) + "\n")
            count += 1

        identity_path = Path(args.identity)
        if identity_path.exists():
            for line in identity_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    output.write(line.strip() + "\n")

    print(f"Wrote {count} AgentPack conversations plus identity examples to {output_path}")
    print(f"Skipped {skipped} records with no recognizable conversation shape")


if __name__ == "__main__":
    main()