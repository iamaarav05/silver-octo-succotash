import { useState, type FormEvent, type KeyboardEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  Activity,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleAlert,
  Code2,
  Cpu,
  Database,
  Gauge,
  GitBranch,
  Layers3,
  LockKeyhole,
  MessageSquarePlus,
  Plus,
  RotateCw,
  Send,
  ShieldCheck,
  Sparkles,
  Terminal,
  X,
  Zap,
} from 'lucide-react';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import {
  useCreateChatCompletion,
  useGetModelStatus,
  useHealthCheck,
} from '@workspace/api-client-react';

const queryClient = new QueryClient();

type LocalMessage = {
  role: 'user' | 'assistant';
  content: string;
};

const starterPrompts = [
  {
    id: 'architecture',
    number: '01',
    kicker: 'BUILD / ARCHITECTURE',
    title: 'Map a small service',
    prompt:
      'Help me sketch a clean architecture for a small TypeScript service that stores notes locally.',
    icon: Layers3,
    tone: 'lime',
  },
  {
    id: 'debug',
    number: '02',
    kicker: 'DEBUG / THINK ALOUD',
    title: 'Find the sharp edge',
    prompt:
      'I have a bug I cannot reproduce consistently. Help me make a concise debugging plan and the right questions to ask.',
    icon: Code2,
    tone: 'coral',
  },
  {
    id: 'explain',
    number: '03',
    kicker: 'LEARN / NO HAND-WAVING',
    title: 'Explain a hard idea',
    prompt:
      'Explain a complex programming concept with a concrete analogy, then show a compact example.',
    icon: Sparkles,
    tone: 'sand',
  },
];

function StatusDot({ ready, loading = false }: { ready: boolean; loading?: boolean }) {
  return (
    <span
      className={`relative flex h-2.5 w-2.5 shrink-0 items-center justify-center rounded-full ${
        ready ? 'bg-[#d6f55a]' : loading ? 'bg-[#efb64f]' : 'bg-[#ef6a4b]'
      }`}
    >
      <span
        className={`absolute inset-[-3px] rounded-full border ${
          ready
            ? 'border-[#d6f55a]/30 status-breathe'
            : loading
              ? 'border-[#efb64f]/30'
              : 'border-[#ef6a4b]/30'
        }`}
      />
    </span>
  );
}

function BrandMark() {
  return (
    <div className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[#d6f55a] text-[#182230] shadow-[3px_3px_0_#52602e]">
      <Terminal size={17} strokeWidth={2.6} />
    </div>
  );
}

function Sidebar({
  modelName,
  modelReady,
  onNewChat,
}: {
  modelName?: string;
  modelReady: boolean;
  onNewChat: () => void;
}) {
  return (
    <aside className="hidden min-h-[100dvh] w-[252px] shrink-0 flex-col border-r border-[#33404c] bg-[#182230] text-[#eef0df] md:flex">
      <div className="flex items-center gap-3 px-6 pb-7 pt-7">
        <BrandMark />
        <div>
          <p className="font-['Space_Grotesk'] text-[17px] font-bold tracking-[-0.04em]">
            Local / 1B
          </p>
          <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#9aa5a0]">
            public workspace
          </p>
        </div>
      </div>

      <div className="px-4">
        <button
          type="button"
          onClick={onNewChat}
          data-testid="button-new-conversation"
          className="group flex w-full items-center justify-between rounded-xl border border-[#44515c] bg-[#222e3b] px-3.5 py-3 text-left transition-colors hover:border-[#d6f55a]/60 hover:bg-[#293746]"
        >
          <span className="flex items-center gap-2.5 text-[13px] font-semibold">
            <MessageSquarePlus size={16} className="text-[#d6f55a]" />
            New conversation
          </span>
          <Plus size={15} className="text-[#82908d] transition-transform group-hover:rotate-90" />
        </button>
      </div>

      <nav className="mt-8 px-4" aria-label="Workspace">
        <p className="px-3 font-mono text-[9px] uppercase tracking-[0.2em] text-[#7d8987]">Workspace</p>
        <div className="mt-2 space-y-1">
          <div className="flex items-center gap-3 rounded-lg bg-[#d6f55a] px-3 py-2.5 text-[13px] font-semibold text-[#182230]">
            <Terminal size={15} />
            Chat
            <span className="ml-auto font-mono text-[9px] opacity-60">01</span>
          </div>
          <div className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] text-[#a6b0a8]">
            <Database size={15} />
            Local context
            <span className="ml-auto rounded bg-[#2d3a45] px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-wider text-[#87938d]">
              soon
            </span>
          </div>
        </div>
      </nav>

      <div className="mt-auto p-4">
        <div className="rounded-xl border border-[#34414c] bg-[#202c39] p-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-[#8c9993]">Loaded model</span>
            <StatusDot ready={modelReady} loading={!modelName} />
          </div>
          <p className="mt-2 truncate font-['Space_Grotesk'] text-[14px] font-semibold text-[#f2f2df]">
            {modelName || 'Checking runtime…'}
          </p>
          <div className="mt-3 flex items-center justify-between border-t border-[#35424d] pt-3 font-mono text-[9px] text-[#8d9a94]">
            <span className="flex items-center gap-1.5"><LockKeyhole size={11} /> prompts stay here</span>
            <ArrowUpRight size={12} />
          </div>
        </div>
        <p className="px-1 pt-4 font-mono text-[9px] uppercase tracking-[0.16em] text-[#67736f]">v0.1 / public runtime</p>
      </div>
    </aside>
  );
}

function ModelPanel({
  model,
  isLoading,
  isError,
  onRefresh,
}: {
  model?: {
    status?: string;
    modelName?: string;
    parameterCount?: string;
    engine?: string;
    contextWindow?: number;
    modelReady?: boolean;
    localOnly?: boolean;
    message?: string;
  };
  isLoading: boolean;
  isError: boolean;
  onRefresh: () => void;
}) {
  const ready = Boolean(model?.modelReady);
  return (
    <aside className="w-full shrink-0 lg:w-[264px]">
      <div className="rounded-2xl border border-[#d8d1c1] bg-[#f8f5ec]/80 p-4 shadow-[0_12px_28px_rgba(40,49,54,.05)]">
        <div className="flex items-start justify-between">
          <div>
            <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#7b817a]">Runtime status</p>
            <div className="mt-2 flex items-center gap-2">
              <StatusDot ready={ready} loading={isLoading} />
              <span data-testid="status-model-state" className="text-[13px] font-semibold capitalize text-[#26313a]">
                {isLoading ? 'checking' : isError ? 'unreachable' : model?.status || 'unknown'}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onRefresh}
            data-testid="button-refresh-status"
            aria-label="Refresh model status"
            className="rounded-lg border border-[#d8d1c1] p-2 text-[#69736f] transition-colors hover:border-[#26313a] hover:bg-[#ebe6d9] hover:text-[#26313a]"
          >
            <RotateCw size={14} />
          </button>
        </div>

        {isLoading ? (
          <div className="mt-5 space-y-2">
            <div className="skeleton-shimmer h-5 w-4/5 rounded" />
            <div className="skeleton-shimmer h-3 w-2/5 rounded" />
            <div className="mt-5 grid grid-cols-2 gap-2">
              <div className="skeleton-shimmer h-14 rounded-lg" />
              <div className="skeleton-shimmer h-14 rounded-lg" />
            </div>
          </div>
        ) : isError ? (
          <div className="mt-5 rounded-xl border border-[#ef6a4b]/25 bg-[#ef6a4b]/8 p-3 text-[12px] leading-relaxed text-[#9d4d3b]">
            <div className="flex items-center gap-2 font-semibold"><CircleAlert size={14} /> Status unavailable</div>
            <p className="mt-1">The runtime did not answer. Chat requests may not be ready yet.</p>
          </div>
        ) : (
          <>
            <p data-testid="text-model-name" className="mt-4 break-words font-['Space_Grotesk'] text-[18px] font-bold leading-tight tracking-[-0.03em] text-[#26313a]">
              {model?.modelName || 'Unnamed server model'}
            </p>
            <p className="mt-1 text-[12px] leading-relaxed text-[#68726f]">{model?.message || 'Ready for a public session.'}</p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Metric label="Parameters" value={model?.parameterCount || '—'} icon={<Cpu size={13} />} />
              <Metric label="Engine" value={model?.engine || '—'} icon={<Zap size={13} />} />
              <Metric label="Context" value={model?.contextWindow ? `${model.contextWindow} tok` : '—'} icon={<Gauge size={13} />} />
              <Metric label="Network" value={model?.localOnly ? 'server' : 'check'} icon={<ShieldCheck size={13} />} />
            </div>
          </>
        )}

        <div className="mt-5 flex items-center gap-2 border-t border-[#ddd6c8] pt-4 font-mono text-[9px] uppercase tracking-[0.14em] text-[#7b817a]">
          <Check size={12} className={model?.localOnly ? 'text-[#648200]' : 'text-[#9a9182]'} />
          {model?.localOnly ? 'No hosted inference' : 'Local inference target'}
        </div>
      </div>

      <div className="mt-3 rounded-2xl border border-[#d8d1c1] bg-[#ebe6d9]/55 p-4">
        <div className="flex items-center gap-2 text-[12px] font-semibold text-[#354149]">
          <GitBranch size={14} className="text-[#69736f]" />
          Why this runtime?
        </div>
          <p className="mt-2 text-[12px] leading-relaxed text-[#727a73]">
          Your prompts stay inside this app&apos;s server runtime. Inspect the model before you trust it.
        </p>
      </div>
    </aside>
  );
}

function Metric({ label, value, icon }: { label: string; value: string; icon: ReactNode }) {
  return (
    <div className="rounded-lg border border-[#ddd6c8] bg-[#f2eee4] p-2.5">
      <div className="flex items-center gap-1.5 text-[#81867e]">{icon}<span className="font-mono text-[8px] uppercase tracking-[0.12em]">{label}</span></div>
      <p className="mt-1.5 truncate font-mono text-[11px] font-medium text-[#344149]">{value}</p>
    </div>
  );
}

function EmptyState({ onChoosePrompt }: { onChoosePrompt: (prompt: string) => void }) {
  return (
    <div className="reveal-up flex flex-1 flex-col justify-center py-8 sm:py-14">
      <div className="flex items-center gap-3">
        <span className="h-px w-8 bg-[#b2bf4f]" />
        <span className="font-mono text-[10px] font-medium uppercase tracking-[0.22em] text-[#76823d]">A public room for useful thinking</span>
      </div>
      <h1 className="mt-6 max-w-[680px] font-['Space_Grotesk'] text-[clamp(2.5rem,6vw,5.1rem)] font-bold leading-[.94] tracking-[-0.075em] text-[#26313a]">
        A quiet terminal<br />
        <span className="text-[#7a8446]">for loud ideas.</span>
      </h1>
      <p className="mt-6 max-w-[500px] text-[15px] leading-[1.7] text-[#66716e]">
        A capable 1B-class assistant that runs on its own server. Ask clearly. See what is running. Keep the thread moving.
      </p>
      <div className="mt-8 flex flex-wrap gap-2">
        <span className="rounded-full border border-[#d2cbbb] bg-[#f8f5ec] px-3 py-1.5 font-mono text-[10px] text-[#69736f]">1B parameters</span>
        <span className="rounded-full border border-[#d2cbbb] bg-[#f8f5ec] px-3 py-1.5 font-mono text-[10px] text-[#69736f]">no hosted API</span>
        <span className="rounded-full border border-[#d2cbbb] bg-[#f8f5ec] px-3 py-1.5 font-mono text-[10px] text-[#69736f]">builder-first</span>
      </div>

      <div className="mt-14">
        <div className="mb-3 flex items-center justify-between">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#7b817a]">Start with a direction</p>
          <p className="hidden font-mono text-[10px] text-[#9b9e93] sm:block">click to load prompt</p>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          {starterPrompts.map((item, index) => {
            const Icon = item.icon;
            const wide = index === 0;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onChoosePrompt(item.prompt)}
                data-testid={`button-starter-${item.id}`}
                className={`group reveal-up reveal-delay-${index + 1} relative overflow-hidden rounded-2xl border p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(38,49,58,.08)] ${
                  wide ? 'md:col-span-2' : ''
                } ${item.tone === 'lime' ? 'border-[#c7d677] bg-[#e9f2bc]' : item.tone === 'coral' ? 'border-[#e5b5a6] bg-[#f5dfd6]' : 'border-[#d9cfbc] bg-[#f1eadb]'}`}
              >
                <div className="flex items-start justify-between">
                  <span className="font-mono text-[10px] text-[#69736f]">{item.number} / {item.kicker}</span>
                  <Icon size={17} className="text-[#4d5a51] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <p className="mt-7 font-['Space_Grotesk'] text-[18px] font-bold tracking-[-0.04em] text-[#29363d]">{item.title}</p>
                <p className="mt-1.5 max-w-[490px] text-[12px] leading-relaxed text-[#68736e]">{item.prompt}</p>
                <div className="mt-4 flex items-center gap-1.5 text-[11px] font-semibold text-[#5b684f]">Use this direction <ArrowUpRight size={13} /></div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Conversation({
  messages,
  isPending,
  responseModel,
}: {
  messages: LocalMessage[];
  isPending: boolean;
  responseModel?: string;
}) {
  return (
    <div className="reveal-up flex-1 space-y-8 py-8 sm:py-12">
      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-[#d8d1c1]" />
        <span className="font-mono text-[9px] uppercase tracking-[0.18em] text-[#969b90]">public thread</span>
        <div className="h-px flex-1 bg-[#d8d1c1]" />
      </div>
      {messages.map((message, index) => {
        const isUser = message.role === 'user';
        return (
          <div key={`${message.role}-${index}`} data-testid={`message-${message.role}-${index}`} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[min(680px,92%)] ${isUser ? 'items-end' : 'items-start'}`}>
              <div className={`mb-2 flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.18em] ${isUser ? 'justify-end text-[#89908a]' : 'text-[#74813c]'}`}>
                {!isUser && <span className="flex h-4 w-4 items-center justify-center rounded bg-[#d6f55a] text-[#26313a]"><Terminal size={9} /></span>}
                {isUser ? 'you' : responseModel || 'server model'}
              </div>
              <div className={`message-copy rounded-2xl px-4 py-3.5 text-[14px] leading-[1.7] ${
                isUser
                  ? 'rounded-tr-sm bg-[#26313a] text-[#f3f1e8]'
                  : 'rounded-tl-sm border border-[#d8d1c1] bg-[#f8f5ec] text-[#38454c] shadow-[0_5px_16px_rgba(40,49,54,.035)]'
              }`}>
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
            </div>
          </div>
        );
      })}
      {isPending && (
        <div data-testid="status-response-loading" className="flex items-start gap-3">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#d6f55a] text-[#26313a]"><Terminal size={14} /></div>
          <div className="rounded-2xl rounded-tl-sm border border-[#d8d1c1] bg-[#f8f5ec] px-4 py-4">
            <div className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-[#78863c] status-breathe" />
              <span className="h-1.5 w-1.5 rounded-full bg-[#78863c] status-breathe [animation-delay:180ms]" />
              <span className="h-1.5 w-1.5 rounded-full bg-[#78863c] status-breathe [animation-delay:360ms]" />
              <span className="ml-2 font-mono text-[10px] text-[#858b80]">thinking on server</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Composer({
  draft,
  onDraftChange,
  onSubmit,
  isPending,
  disabled,
  onClearError,
  error,
}: {
  draft: string;
  onDraftChange: (value: string) => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  isPending: boolean;
  disabled: boolean;
  onClearError: () => void;
  error: string | null;
}) {
  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      event.currentTarget.form?.requestSubmit();
    }
  };
  return (
    <div className="sticky bottom-0 z-10 -mx-4 border-t border-[#d8d1c1] bg-[#f0ede4]/95 px-4 pb-4 pt-4 backdrop-blur-md sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12">
      <div className="mx-auto max-w-[860px]">
        {error && (
          <div data-testid="status-chat-error" className="mb-3 flex items-center justify-between rounded-xl border border-[#ef6a4b]/25 bg-[#f5dfd6] px-3 py-2.5 text-[12px] text-[#974c3a]">
            <span className="flex items-center gap-2"><CircleAlert size={14} /> {error}</span>
            <button type="button" onClick={onClearError} data-testid="button-dismiss-error" aria-label="Dismiss error" className="rounded p-1 hover:bg-[#ef6a4b]/10"><X size={14} /></button>
          </div>
        )}
        <form onSubmit={onSubmit} className="relative rounded-2xl border border-[#bdb8a9] bg-[#f8f5ec] p-2 shadow-[0_10px_30px_rgba(38,49,58,.08)] transition-colors focus-within:border-[#7c8c3a] focus-within:shadow-[0_10px_30px_rgba(120,140,58,.12)]">
          <textarea
            value={draft}
            onChange={(event) => onDraftChange(event.target.value)}
            onKeyDown={handleKeyDown}
            data-testid="input-chat-message"
            rows={2}
            placeholder="Ask the public assistant anything..."
            className="min-h-[56px] w-full resize-none bg-transparent px-3 py-2 text-[14px] leading-relaxed text-[#26313a] outline-none placeholder:text-[#969a91]"
            disabled={isPending}
          />
          <div className="flex items-center justify-between px-2 pb-1">
            <div className="flex items-center gap-2 font-mono text-[9px] uppercase tracking-[0.12em] text-[#9a9b8f]">
              <span className="flex items-center gap-1.5"><LockKeyhole size={11} /> runs on server</span>
              <span className="hidden text-[#c4bdae] sm:inline">·</span>
              <span className="hidden sm:inline">shift + enter for a new line</span>
            </div>
            <button
              type="submit"
              disabled={disabled || isPending}
              data-testid="button-send-message"
              aria-label="Send message"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#26313a] text-[#d6f55a] transition-all hover:bg-[#374751] hover:shadow-[3px_3px_0_#9cae47] disabled:cursor-not-allowed disabled:opacity-35 disabled:shadow-none"
            >
              {isPending ? <RotateCw size={15} className="animate-spin" /> : <Send size={15} />}
            </button>
          </div>
        </form>
        <p className="pt-2 text-center font-mono text-[9px] uppercase tracking-[0.14em] text-[#a09f92]">Server output can be wrong. Keep a human in the loop.</p>
      </div>
    </div>
  );
}

function Home() {
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastModel, setLastModel] = useState<string | undefined>();

  const health = useHealthCheck();
  const status = useGetModelStatus();
  const chat = useCreateChatCompletion();

  const model = status.data;
  const hasMessages = messages.length > 0;
  const runtimeReady = Boolean(model?.modelReady);

  const startNewChat = () => {
    setMessages([]);
    setDraft('');
    setErrorMessage(null);
    setLastModel(undefined);
    chat.reset();
  };

  const submitMessage = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const content = draft.trim();
    if (!content || chat.isPending) return;
    setErrorMessage(null);
    const userMessage: LocalMessage = { role: 'user', content };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft('');
    chat.mutate(
      { data: { messages: nextMessages, temperature: 0.7, maxTokens: 512 } },
      {
        onSuccess: (response) => {
          setLastModel(response.model);
          setMessages((current) => [...current, { role: 'assistant', content: response.message.content }]);
        },
        onError: (error) => {
          const possibleError = error as { error?: string; message?: string };
          setErrorMessage(possibleError.error || possibleError.message || 'The server runtime could not complete that request.');
        },
      },
    );
  };

  return (
    <div className="min-h-[100dvh] bg-[#f0ede4] text-[#26313a]">
      <div className="flex min-h-[100dvh]">
        <Sidebar modelName={model?.modelName} modelReady={runtimeReady} onNewChat={startNewChat} />
        <main className="workspace-grid flex min-h-[100dvh] min-w-0 flex-1 flex-col">
          <header className="flex h-[72px] shrink-0 items-center justify-between border-b border-[#d8d1c1] bg-[#f0ede4]/85 px-4 backdrop-blur-md sm:px-8 lg:px-12">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 md:hidden">
                <BrandMark />
                <span className="font-['Space_Grotesk'] text-[15px] font-bold tracking-[-0.04em]">Local / 1B</span>
              </div>
              <div className="hidden items-center gap-2 md:flex">
                <span className="font-mono text-[10px] uppercase tracking-[0.17em] text-[#8c9085]">Workspace</span>
                <span className="text-[#c0b9a9]">/</span>
                <span className="font-mono text-[10px] uppercase tracking-[0.17em] text-[#536057]">New conversation</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div data-testid="status-health" className="hidden items-center gap-2 font-mono text-[9px] uppercase tracking-[0.14em] text-[#78817b] sm:flex">
                <Activity size={13} className={health.isError ? 'text-[#ef6a4b]' : 'text-[#75863b]'} />
                {health.isLoading ? 'checking service' : health.isError ? 'service offline' : `service ${health.data?.status || 'online'}`}
              </div>
              <div data-testid="status-local-only" className="flex items-center gap-2 rounded-full border border-[#c7d677] bg-[#e9f2bc] px-3 py-1.5 font-mono text-[9px] font-medium uppercase tracking-[0.12em] text-[#53621f]">
                <LockKeyhole size={11} />
                server inference
              </div>
            </div>
          </header>

          <div className="flex flex-1 flex-col px-4 sm:px-8 lg:px-12">
            <div className="mx-auto flex w-full max-w-[1180px] flex-1 flex-col lg:flex-row lg:gap-10">
              <section className="flex min-w-0 flex-1 flex-col">
                {hasMessages ? (
                  <Conversation messages={messages} isPending={chat.isPending} responseModel={lastModel} />
                ) : (
                  <EmptyState onChoosePrompt={setDraft} />
                )}
                <Composer
                  draft={draft}
                  onDraftChange={setDraft}
                  onSubmit={submitMessage}
                  isPending={chat.isPending}
                  disabled={!draft.trim()}
                  error={errorMessage}
                  onClearError={() => setErrorMessage(null)}
                />
              </section>
              <div className="hidden pt-8 lg:block lg:w-[264px] lg:pt-10">
                <ModelPanel
                  model={model}
                  isLoading={status.isLoading}
                  isError={status.isError}
                  onRefresh={() => {
                    void status.refetch();
                    void health.refetch();
                  }}
                />
              </div>
            </div>
            <div className="pb-6 pt-2 lg:hidden">
              <details className="group rounded-xl border border-[#d8d1c1] bg-[#f8f5ec]">
                <summary data-testid="button-toggle-runtime-details" className="flex cursor-pointer list-none items-center justify-between px-4 py-3 text-[12px] font-semibold text-[#48554f]">
                  <span className="flex items-center gap-2"><Cpu size={14} /> Runtime details</span>
                  <ChevronDown size={15} className="transition-transform group-open:rotate-180" />
                </summary>
                <div className="border-t border-[#d8d1c1] p-3">
                  <ModelPanel
                    model={model}
                    isLoading={status.isLoading}
                    isError={status.isError}
                    onRefresh={() => {
                      void status.refetch();
                      void health.refetch();
                    }}
                  />
                </div>
              </details>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function NotFound() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#f0ede4] px-6 text-center">
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#78863c]">404 / outside the workspace</p>
        <h1 className="mt-4 font-['Space_Grotesk'] text-4xl font-bold tracking-[-0.06em] text-[#26313a]">Nothing running here.</h1>
        <a href="/" data-testid="link-back-home" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#26313a] px-4 py-2.5 text-sm font-semibold text-[#d6f55a]">Return to chat <ArrowUpRight size={14} /></a>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <Router />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;