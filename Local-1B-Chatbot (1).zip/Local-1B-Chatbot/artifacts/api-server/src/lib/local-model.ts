import { randomUUID } from "node:crypto";
import { pipeline } from "@huggingface/transformers";

export type ChatRole = "system" | "user" | "assistant";

export type ChatMessage = {
  role: ChatRole;
  content: string;
};

export type ModelStatus = {
  status: "ready" | "setup" | "unavailable" | "loading";
  modelName: string;
  parameterCount: string;
  engine: string;
  contextWindow: number;
  modelReady: boolean;
  localOnly: boolean;
  message: string;
};

const modelId =
  process.env.LOCAL_MODEL_ID ??
  "onnx-community/Llama-3.2-1B-Instruct-ONNX";
const modelName = process.env.LOCAL_MODEL_NAME ?? "Llama 3.2 1B Instruct";
const modelParameterCount = process.env.LOCAL_MODEL_PARAMETERS ?? "1.2B";
const contextWindow = Number(process.env.LOCAL_MODEL_CONTEXT ?? 2048);
const identityPrompt =
  process.env.LOCAL_SYSTEM_PROMPT ??
  "You are Local/1B, a public self-hosted AI assistant running on this server through an open-weight 1B-class model. If asked who you are, say clearly that you are Local/1B, not ChatGPT, and that you use this application's own API without a hosted LLM provider. Be honest, concise, and helpful.";

export function getModelName() {
  return modelName;
}

type TextGenerator = ((
  messages: Array<{ role: ChatRole; content: string }>,
  options: {
    max_new_tokens: number;
    temperature: number;
    do_sample: boolean;
    return_full_text: boolean;
  },
) => Promise<Array<{ generated_text: string | ChatMessage[] }>>) & {
  tokenizer?: {
    apply_chat_template?: (
      messages: ChatMessage[],
      options: { tokenize: boolean; add_generation_prompt: boolean },
    ) => string;
  };
};

let generator: TextGenerator | null = null;
let loadPromise: Promise<TextGenerator> | null = null;
let loadError: string | null = null;

function loadingMessage() {
  return "The public model is downloading and warming up. The first request may take a few minutes.";
}

async function loadModel() {
  if (generator) return generator;
  if (loadPromise) return loadPromise;

  loadError = null;
  loadPromise = pipeline("text-generation", modelId, {
    dtype: "q4",
  })
    .then((loaded) => {
      generator = loaded as unknown as TextGenerator;
      return generator;
    })
    .catch((error: unknown) => {
      loadError =
        error instanceof Error
          ? error.message
          : "The public model could not be loaded.";
      throw error;
    })
    .finally(() => {
      loadPromise = null;
    });

  return loadPromise;
}

export function startModelWarmup() {
  void loadModel().catch(() => {
    // The status endpoint exposes the error. Startup must remain available
    // while a deployment retries or the model repository is temporarily down.
  });
}

export async function getModelStatus(): Promise<ModelStatus> {
  if (generator) {
    return {
      status: "ready",
      modelName,
      parameterCount: modelParameterCount,
      engine: "Transformers.js / ONNX Runtime",
      contextWindow,
      modelReady: true,
      localOnly: true,
      message: "Running on this server. Prompts are not sent to an LLM API.",
    };
  }

  if (loadError) {
    return {
      status: "unavailable",
      modelName,
      parameterCount: modelParameterCount,
      engine: "Transformers.js / ONNX Runtime",
      contextWindow,
      modelReady: false,
      localOnly: true,
      message: `Model load failed: ${loadError}`,
    };
  }

  if (loadPromise) {
    return {
      status: "loading",
      modelName,
      parameterCount: modelParameterCount,
      engine: "Transformers.js / ONNX Runtime",
      contextWindow,
      modelReady: false,
      localOnly: true,
      message: loadingMessage(),
    };
  }

  return {
    status: "setup",
    modelName,
    parameterCount: modelParameterCount,
    engine: "Transformers.js / ONNX Runtime",
    contextWindow,
    modelReady: false,
    localOnly: true,
    message: "The public model will download automatically on startup.",
  };
}

function normalizeGeneratedText(value: string | ChatMessage[]) {
  if (typeof value === "string") {
    return value.trim();
  }
  const assistantMessage = [...value].reverse().find((item) => item.role === "assistant");
  return assistantMessage?.content.trim() ?? "";
}

export async function generateLocalResponse(
  messages: ChatMessage[],
  options: { temperature: number; maxTokens: number },
) {
  const model = await loadModel();
  const conversation =
    messages[0]?.role === "system"
      ? messages
      : [{ role: "system" as const, content: identityPrompt }, ...messages];
  const output = await model(conversation, {
    max_new_tokens: options.maxTokens,
    temperature: options.temperature,
    do_sample: options.temperature > 0,
    return_full_text: false,
  });
  const content = normalizeGeneratedText(output[0]?.generated_text ?? "");

  if (!content) {
    throw new Error("The public model returned an empty response.");
  }

  return { id: `chatcmpl-${randomUUID()}`, content };
}

export function estimateTokens(value: string) {
  return Math.max(1, Math.ceil(value.trim().length / 4));
}