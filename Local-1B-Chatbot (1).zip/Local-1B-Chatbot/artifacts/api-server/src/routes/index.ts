import { Router, type IRouter } from "express";
import healthRouter from "./health";
import modelRouter from "./model";
import chatRouter from "./chat";

const router: IRouter = Router();

router.use(healthRouter);
router.use(modelRouter);
router.use(chatRouter);

export default router;
