import { Router, type IRouter, type Request } from "express";
import {
  CreateChatCompletionBody,
  CreateChatCompletionResponse,
} from "@workspace/api-zod";
import {
  estimateTokens,
  generateLocalResponse,
  getModelName,
  type ChatMessage,
} from "../lib/local-model";

const router: IRouter = Router();
const windowMs = Number(process.env.CHAT_RATE_WINDOW_MS ?? 10 * 60 * 1000);
const maxRequests = Number(process.env.CHAT_RATE_MAX_REQUESTS ?? 20);
const maxConcurrent = Number(process.env.CHAT_MAX_CONCURRENT ?? 2);
const visitors = new Map<string, { startedAt: number; count: number }>();
let activeGenerations = 0;

function visitorKey(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.length > 0) {
    return forwarded.split(",")[0].trim();
  }
  return req.ip ?? req.socket.remoteAddress ?? "unknown";
}

router.post("/chat", async (req, res) => {
  const now = Date.now();
  const key = visitorKey(req);
  const visitor = visitors.get(key);
  const current =
    visitor && now - visitor.startedAt < windowMs
      ? visitor
      : { startedAt: now, count: 0 };

  if (current.count >= maxRequests) {
    const retryAfterSeconds = Math.max(
      1,
      Math.ceil((current.startedAt + windowMs - now) / 1000),
    );
    res.setHeader("Retry-After", retryAfterSeconds);
    res.status(429).json({
      error: `Message limit reached. Try again in about ${Math.ceil(retryAfterSeconds / 60)} minutes.`,
    });
    return;
  }

  if (activeGenerations >= maxConcurrent) {
    res.setHeader("Retry-After", "10");
    res.status(429).json({
      error: "The public model is busy. Please retry in a few seconds.",
    });
    return;
  }

  current.count += 1;
  visitors.set(key, current);
  activeGenerations += 1;

  const parsed = CreateChatCompletionBody.safeParse(req.body);
  if (!parsed.success) {
    activeGenerations -= 1;
    res.status(400).json({ error: "Invalid chat request." });
    return;
  }

  try {
    const { messages, temperature, maxTokens } = parsed.data;
    const result = await generateLocalResponse(messages as ChatMessage[], {
      temperature,
      maxTokens,
    });
    const promptTokens = estimateTokens(
      messages.map((message) => message.content).join("\n"),
    );
    const completionTokens = estimateTokens(result.content);
    const data = CreateChatCompletionResponse.parse({
      id: result.id,
      model: getModelName(),
      message: { role: "assistant", content: result.content },
      usage: {
        promptTokens,
        completionTokens,
        totalTokens: promptTokens + completionTokens,
      },
      localOnly: true,
    });
    res.json(data);
  } catch (error) {
    req.log.warn({ error }, "Local model generation failed");
    res.status(503).json({
      error:
        error instanceof Error
          ? error.message
          : "The local model is not ready.",
    });
  } finally {
    activeGenerations -= 1;
  }
});

export default router;