import { Router, type IRouter } from "express";
import { GetModelStatusResponse } from "@workspace/api-zod";
import { getModelStatus } from "../lib/local-model";

const router: IRouter = Router();

router.get("/model/status", async (_req, res) => {
  const data = GetModelStatusResponse.parse(await getModelStatus());
  res.json(data);
});

export default router;