# Local 1B Chatbot

A public chat workspace that runs an open-weight 1B-class model on its own server through a first-party API.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/local-chatbot run typecheck` — typecheck the web app
- `pnpm --filter @workspace/api-server run typecheck` — typecheck the API
- The public server downloads the model automatically for real inference. See `docs/local-model.md`.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/local-chatbot` — React/Vite chat interface
- `artifacts/api-server/src/lib/local-model.ts` — server-side Transformers.js / ONNX model runtime
- `artifacts/api-server/src/routes` — model status and chat endpoints
- `lib/api-spec/openapi.yaml` — API source of truth

## Architecture decisions

- The app never calls a hosted LLM provider; `/api/chat` runs a downloaded open-weight model on the API server.
- The model repository and runtime are configurable with environment variables so the inference engine can be upgraded without rewriting the UI.
- Chat history stays in the browser for the first version; the API remains stateless and accepts the conversation on each request.

## Product

- See whether the public model is loaded and ready.
- Send multi-turn messages to the server-side model.
- See token usage and server-runtime state for each response.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- The API returns HTTP 503 only while the public model is downloading or if the server cannot load it; it does not fall back to a hosted service.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
