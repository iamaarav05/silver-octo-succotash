# Train Local/1B on AgentPack

This project now includes a reproducible LoRA fine-tuning workflow for
`nuprl/AgentPack`. It also adds identity examples so the assistant learns to
answer questions such as “Who are you?” with a clear description of the
self-hosted Local/1B assistant.

## 1. Use a GPU machine

Full 1B fine-tuning is not practical on the current CPU-only development
workspace. Use a machine with an NVIDIA GPU and install the dependencies from
`training/requirements.txt`:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r training/requirements.txt
```

## 2. Prepare AgentPack

The preparation script uses the same API pattern you provided:

```python
from datasets import load_dataset

ds = load_dataset("nuprl/AgentPack")
```

Run:

```bash
python training/prepare_agentpack.py \
  --dataset nuprl/AgentPack \
  --split train \
  --output training/data/agentpack_chat.jsonl
```

It recognizes common AgentPack conversation fields (`messages`,
`conversation`, `trajectory`, `prompt`/`response`, and similar shapes), adds
the Local/1B system identity, and appends the examples in
`training/identity.jsonl`.

Inspect the generated JSONL before training. If the dataset revision uses a
new field shape, add that field name to `normalize_record()` rather than
silently training on empty examples.

## 3. Fine-tune with LoRA

```bash
python training/train_lora.py \
  --base-model meta-llama/Llama-3.2-1B-Instruct \
  --data training/data/agentpack_chat.jsonl \
  --output training/output/local-1b-agentpack-lora \
  --epochs 1
```

LoRA trains a small adapter instead of rewriting every parameter in the 1B
model. This is faster, cheaper, and easier to iterate on. The script enables
mixed precision and gradient checkpointing when a compatible GPU is present.

## 4. Serve the trained model

The current public runtime uses the ONNX model
`onnx-community/Llama-3.2-1B-Instruct-ONNX`. A LoRA adapter must be merged
into the matching base model and exported to an ONNX model repository before it
can be served by Transformers.js. Do not merge a TinyLlama adapter into the
Llama 3.2 runtime; the base model must match.

The Llama base model may require accepting its model license on Hugging Face
before downloading it. That is model access, not an LLM inference API.

After exporting the matching trained model, configure the public API:

```bash
export LOCAL_MODEL_ID="your-account/your-trained-1b-onnx"
export LOCAL_MODEL_NAME="Local/1B AgentPack"
export LOCAL_MODEL_PARAMETERS="1.1B"
```

The existing `/api/model/status` endpoint will report the configured model,
and `/api/chat` will use it without any hosted LLM API.