# Local model setup

The chat API is intentionally self-hosted. It does not require an OpenAI, Anthropic, Gemini, or other hosted model key.

## Public deployment

The public server downloads the quantized ONNX model automatically from its
model repository on first startup. Visitors do not install anything and do not
need a model file or API key.

The default model is `onnx-community/Llama-3.2-1B-Instruct-ONNX` and runs
through Transformers.js and ONNX Runtime on the API server. The first startup
can take a few minutes while the model is cached.

To use a different compatible model, configure the API server:

```bash
export LOCAL_MODEL_ID="onnx-community/Llama-3.2-1B-Instruct-ONNX"
export LOCAL_MODEL_NAME="Llama 3.2 1B Instruct"
export LOCAL_MODEL_PARAMETERS="1.2B"
```

The API exposes:

- `GET /api/model/status` — reports whether the model is ready
- `POST /api/chat` — accepts the full conversation and runs inference on the public server

Example request:

```bash
curl -X POST http://localhost:80/api/chat \
  -H 'content-type: application/json' \
  -d '{"messages":[{"role":"user","content":"Explain recursion in one paragraph."}]}'
```

The server returns `503` only if the model repository cannot be downloaded or
the runtime fails. It never silently routes the prompt to a cloud provider.